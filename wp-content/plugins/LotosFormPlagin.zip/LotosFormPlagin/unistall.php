<?php

if (!define('WP_UNINSTALL_PLUGIN')) {
    exit;
}